This is an empty directory for you to work from.
